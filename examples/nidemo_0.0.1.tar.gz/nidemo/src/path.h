#ifndef NI_PATH_H_
#define NI_PATH_H_

#include <Rinternals.h>

/* Expand a path name, for example by replacing a leading tilde by the
   user's home directory (if defined on that platform).

   Implemented by calling R's path.expand R function to demonstrate
   calling R functions from C.
 */
const char *
nid_path_expand(const char *s);


#endif
